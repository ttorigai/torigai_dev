﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using System.IO;
using System.Linq;
using System.Text;

namespace MefPluginTest
{
    public class MefPluginManager
    {
        private CompositionContainer _container;

        [ImportMany]
        public IEnumerable<ITestPlugin> Plugins { get; private set; }        

        public MefPluginManager() 
        {
            Plugins = new List<ITestPlugin>();
        }

        public void RunComposition()
        {
            var catalog = new AggregateCatalog();
            //Adds all the parts found in the same assembly as the Program class
            catalog.Catalogs.Add(new AssemblyCatalog(typeof(MefPluginManager).Assembly));
            catalog.Catalogs.Add(new DirectoryCatalog(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, Program.PLUGIN_PATH)));
            
            //Create the CompositionContainer with the parts in the catalog
            _container = new CompositionContainer(catalog);

            //Fill the imports of this object
            try
            {
                this._container.ComposeParts(this);
            }
            catch (CompositionException compositionException)
            {
                Console.WriteLine(compositionException.ToString());
            }
        }
    }
}
