﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MefPluginTest
{
    public interface ITestPlugin
    {
        string ShowMessage();
    }
}
