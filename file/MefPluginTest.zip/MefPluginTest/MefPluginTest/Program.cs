﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.Composition;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;

namespace MefPluginTest
{
    class Program
    {
        public const string PLUGIN_PATH = "plugins";

        static MefPluginManager _mgr;
        static bool _reset = false;

        static void Main(string[] args)
        {
            FileSystemWatcher fsw = new FileSystemWatcher();
            fsw.Filter = "*.dll";
            fsw.Created += new FileSystemEventHandler(DirectoryChanged);
            fsw.Changed += new FileSystemEventHandler(DirectoryChanged);

            BackgroundWorker bw = new BackgroundWorker();
            bw.DoWork += new DoWorkEventHandler(Process);
            bw.WorkerSupportsCancellation = true;
            bw.RunWorkerAsync();

            Console.WriteLine("Press any key to exit");
            Console.ReadLine();

            bw.CancelAsync();

            Console.WriteLine("Exiting...");
        }

        static void DirectoryChanged(object sender, FileSystemEventArgs e)
        {
            _reset = true;
        }

        static void Process(object sender, DoWorkEventArgs e)
        {
            BackgroundWorker bw = sender as BackgroundWorker;
            if (bw == null) throw new Exception("Invalid sender");

            Console.WriteLine("Begin processing...");
            
            while (!bw.CancellationPending)
            {
                try
                {
                    Console.WriteLine("{0}: running plugins...", DateTime.Now);
                    // first step: load plugins
                    TestForPlugins();
                    // next step: show off the plugins
                    RunPlugins();
                    // final step: pause for effect
                    Thread.Sleep(2000);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Exception: {0}", ex.Message);
                    return;
                }
            }
        }

        static void TestForPlugins()
        {
            _mgr = new MefPluginManager();
            if (_mgr.Plugins.Count() == 0 || _reset)
            {
                _mgr.RunComposition();
                _reset = false;
            }
        }

        static void RunPlugins()
        {
            foreach (ITestPlugin p in _mgr.Plugins)
            {
                Console.WriteLine(p.ShowMessage());
            }
        }
    }
}
