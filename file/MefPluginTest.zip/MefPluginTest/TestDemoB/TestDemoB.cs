﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;

using MefPluginTest;

namespace TestDemoB
{
    [Export(typeof(ITestPlugin))]
    public class TestDemoB : ITestPlugin
    {
        const string VER = "1.0.5";

        public string ShowMessage()
        {
            return string.Format("{0}: TestDemoB Mef dll, version {1}", DateTime.Now, VER);
        }
    }
}
