﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PluginLoadTest
{
    public interface ITestPlugin
    {
        string ShowMessage();
    }
}
