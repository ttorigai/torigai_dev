﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;

namespace PluginLoadTest
{
    class Program
    {
        public const string PLUGIN_PATH = "plugins";
        
        static Dictionary<string, DateTime> _loadedDlls;
        static Dictionary<string, ITestPlugin> _loadedPlugins;

        static void Main(string[] args)
        {
            BackgroundWorker bw = new BackgroundWorker();
            bw.DoWork += new DoWorkEventHandler(Process);
            bw.WorkerSupportsCancellation = true;
            bw.RunWorkerAsync();

            Console.WriteLine("Press any key to exit");
            Console.ReadLine();

            bw.CancelAsync();

            Console.WriteLine("Exiting...");
        }

        static void Process(object sender, DoWorkEventArgs e)
        {
            BackgroundWorker bw = sender as BackgroundWorker;
            if (bw == null) throw new Exception("Invalid sender");

            Console.WriteLine("Begin processing...");
                        
            _loadedDlls = new Dictionary<string, DateTime>();
            _loadedPlugins = new Dictionary<string, ITestPlugin>();

            while (!bw.CancellationPending)
            {
                try
                {
                    Console.WriteLine("{0}: running plugins...", DateTime.Now);
                    // first step: load plugins
                    TestForPlugins();
                    // next step: show off the plugins
                    RunPlugins();
                    // final step: pause for effect
                    Thread.Sleep(2000);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Exception: {0}", ex.Message);
                    return;
                }
            }
        }

        private static void TestForPlugins()
        {
            // assumes hardcoded plugins subdirectory
            DirectoryInfo dir = new DirectoryInfo(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, PLUGIN_PATH));
            PluginManager mgr = new PluginManager();

            foreach (FileInfo file in dir.GetFiles("*.dll"))
            {
                // in this simplistic example, the type that derives from ITestPlugin will be named the same as the dll it's loaded from
                // could use a config file to get dll and type names, then just test the dll file timestamp as necessary
                if (!_loadedDlls.ContainsKey(file.Name) || (_loadedDlls[file.Name] != file.LastWriteTimeUtc))
                {                                            
                    ITestPlugin plugin = mgr.Load(Path.GetFileNameWithoutExtension(file.Name), file.FullName);
                    if (plugin != null)
                    {
                        _loadedPlugins[file.Name] = plugin;
                        _loadedDlls[file.Name] = file.LastWriteTimeUtc;
                    }
                }
            }
        }

        private static void RunPlugins()
        {
            foreach (ITestPlugin plugin in _loadedPlugins.Values)
            {
                Console.WriteLine(plugin.ShowMessage());
            }
        }
    }
}
