﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace PluginLoadTest
{
    public class PluginManager
    {
        public ITestPlugin Load(string type, string filename)
        {            
            String pluginsPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, Program.PLUGIN_PATH);

            // Setup the Domain
            var setupInfo = new AppDomainSetup();
            setupInfo.ApplicationBase = AppDomain.CurrentDomain.BaseDirectory;
            setupInfo.PrivateBinPath = pluginsPath;
            setupInfo.ShadowCopyFiles = "true";
            setupInfo.CachePath = Path.Combine(pluginsPath, "cache");
            setupInfo.ShadowCopyDirectories = pluginsPath;

            // Create the new AppDomain for the service
            AppDomain currentDomain = AppDomain.CreateDomain("PluginLoadTest", null, setupInfo);
            
            // Can pass data to the domain with this method, could be handy for runtime config
            //currentDomain.SetData("DataName", value);       
            
            // As noted elsewhere, 
            // in this simplistic example, the type that derives from ITestPlugin 
            // will be named the same as the dll it's loaded from (however we need
            // to add the namespace to actually create the instance
            return currentDomain.CreateInstanceAndUnwrap(type, BuildFullTypeName(type)) as ITestPlugin;            
        }

        public string BuildFullTypeName(string type)
        {
            return string.Format("PluginLoadTest.{0}", type);
        }
    }
}
