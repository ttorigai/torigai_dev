﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PluginLoadTest
{
    [Serializable]
    public class TestDemoA : MarshalByRefObject, ITestPlugin
    {
        const string VER = "1.0.1";

        public string ShowMessage()
        {
            return string.Format("{0}: TestDemoA dll, version {1}", DateTime.Now, VER);
        }
    }
}
